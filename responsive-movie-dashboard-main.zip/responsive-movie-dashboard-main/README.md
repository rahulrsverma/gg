# Responsive Movie Admin Dashboard
## [Watch it on youtube](https://youtu.be/2n5FD2wLvwA)
### Responsive Movie Admin Dashboard

- Responsive Movie Admin Dashboard Using HTML CSS And JavaScript
- Contains a responsive side panel and search bar.
- Contains banner, movies and new sections.
- Developed first with the Mobile First methodology, then for desktop.
- Compatible with all mobile devices and with a beautiful and pleasant user interface.

💙 Join the channel to see more videos like this. [Bedimcode](https://www.youtube.com/@Bedimcode)

![preview img](/preview.png)
